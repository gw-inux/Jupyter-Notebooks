---
title: Soil Physics
layout: home
nav_order: 3
parent: Streamlit Apps
has_children: false
---

### Streamlit Apps for the topic

# 03 Soil Physics

### Soil Water Retention Characteristics

<img src="..\assets\images\st\03\Soil Water Retention Characteristics.png" alt="Screenshot of the app" width="400" />



You can **access the app** here: https://soil-water-retention.streamlit.app/
