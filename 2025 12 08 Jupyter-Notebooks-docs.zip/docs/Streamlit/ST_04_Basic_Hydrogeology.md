---
title: Basic Hydrogeology
layout: home
nav_order: 4
parent: Streamlit Apps
has_children: true
---

<script type="text/javascript" async
    src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/3.2.2/es5/tex-mml-chtml.js">
</script>

#### Streamlit Apps for the topic
# 04 Basic Hydrogeology

The apps are organized in subcategories. You find them below or in the sidebar menu.
