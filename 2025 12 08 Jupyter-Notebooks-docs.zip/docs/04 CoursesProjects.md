---
title: Courses and Projects
layout: home
nav_order: 4
has_children: true
---

# Courses and Projects based on the Jupyter Notebooks

The Jupyter Notebooks from the repository can be implemented in courses and projects. Those are subsequently hosted to allow users working with the notebooks but also to demonstrate future users a way of implementing the Jupyter Notebooks in their own activities.